% up to 6/22
% simulate the calcium in the pore water
close all;
clear all;

s1081_alk_main;

load workspace_1081.mat;

alpha=a(1);
beta=a(2);
gamma=a(3);
R_net = alpha+beta*exp(-z/gamma) ;

v=a(4);
gra_alk = a(5);

%------- initialize the paramter------
D0 = zeros(length(z),1);
D_alk = zeros(length(z),1);

for i = 1:length(z)
    D0(i) = (3.69+ 0.169 * (temp_T(i)-273.15)) * 3.65 * 24 * 36;
    D_alk(i) = D0(i) / (1-log(phi_z(i)^2))*1.4265;
end


%------- initialize the paramter------
J = length(z);
N = length(t);
alk_pore = zeros(N,J);
K_aq = 0;   % adsoprtion coefficient 

for n =1:N
    alk_pore(n,n:n+1) = 3.23 + 0.0*t(N-n+1);
end

alk_pore(2,1) = alk_pore(2,2)+ z_step(2)* gra_alk;


%-----calculation
for n = 2: N-1
    
    a10 = 2*D_alk(n-2+1)*t_step/z_step(n-2+2)^2;
    b10 = t_step*v/z_step(n-2+2);

    alk_pore(n+1,2) = ((a10-b10)*alk_pore(n,2+1) + (a10+b10)*(alk_pore(n, 3) + 2 * z_step(n)* gra_alk) + (1-a10)*alk_pore(n-1,2) + 2*t_step*R_net(n-2+1)) / (1+a10);
      
    for j = 3:n
        
        a1 = 2*D_alk(n-j+1)*t_step/z_step(n-j+2)^2;
        b1 = t_step*v/z_step(n-j+2);
        
        alk_pore(n+1,j) = ((a1-b1)*alk_pore(n,j+1) + (a1+b1)*alk_pore(n,j-1) + (1-a1)*alk_pore(n-1,j) + 2*t_step*R_net(n-j+1)) / (1+a1);
        
    end
    
end

alk_pore(:,1)=alk_pore(:,2);


t_total = t(end);
%-------end of paste--------
t1 = round((t_total/4)/t_step);
t2 = round((t_total/2)/t_step);
t3 = round((t_total/4*3)/t_step);

figure
plot(fliplr(alk_pore(N,1:J)),z,'linewidth',2)
hold on
plot(fliplr(alk_pore(N-t1,1:J-t1)),z(1+t1:end),'--','linewidth',2)
plot(fliplr(alk_pore(N-t2,1:J-t2)),z(1+t2:end),':','linewidth',2)
plot(fliplr(alk_pore(N-t3,1:J-t3)),z(1+t3:end),'-.','linewidth',2)
 

set(gca,'Ydir','reverse')
title("Site 1081");
xlabel('Alkalinity (mM) in pore water');
ylabel('Present-day depth (m)')
set(gca,'FontSize',12)

[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk_data=AlkalinityALKmM(index);

scatter (alk_data,depth);

legend('t= present day','0.75t','0.5t','0.25t','Alkalinity Data','location','best')

print('alk1081.jpg','-djpeg','-r600');

R_alk=R_net;

newName = 'z1081';
S.(newName) = z;

newName = 'Ralk1081';
S.(newName) = R_alk;

save('alk1081.mat', '-struct', 'S'); 



