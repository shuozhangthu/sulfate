% up to 6/22
% simulate the calcium in the pore water
close all;
clear all;

s981_Mg_main;

load workspace_981.mat;

alpha=m(1);
beta=m(2);
gamma=m(3);
R_net = alpha+beta*exp(-z/gamma) ;

v=m(4);
gra_mg = m(5);

%------- initialize the paramter------
D0 = zeros(length(z),1);
D_mg = zeros(length(z),1);

for i = 1:length(z)
    D0(i) = (3.69+ 0.169 * (temp_T(i)-273.15)) * 3.65 * 24 * 36;
    D_mg(i) = D0(i) / (1-log(phi_z(i)^2))*0.9265;
end


%------- initialize the paramter------
J = length(z);
N = length(t);
Mg_pore = zeros(N,J);
K_aq = 0;   % adsoprtion coefficient 

for n =1:N
    Mg_pore(n,n:n+1) = 52.58 + 0*t(N-n+1);
end

Mg_pore(2,1) = Mg_pore(2,2)+ z_step(2)* gra_mg;


%-----calculation
for n = 2: N-1
    
    a10 = 2*D_mg(n-2+1)*t_step/z_step(n-2+2)^2;
    b10 = t_step*v/z_step(n-2+2);

    Mg_pore(n+1,2) = ((a10-b10)*Mg_pore(n,2+1) + (a10+b10)*(Mg_pore(n, 3) + 2 * z_step(n)* gra_mg) + (1-a10)*Mg_pore(n-1,2) + 2*t_step*R_net(n-2+1)) / (1+a10);
      
    for j = 3:n
        
        a1 = 2*D_mg(n-j+1)*t_step/z_step(n-j+2)^2;
        b1 = t_step*v/z_step(n-j+2);
        
        Mg_pore(n+1,j) = ((a1-b1)*Mg_pore(n,j+1) + (a1+b1)*Mg_pore(n,j-1) + (1-a1)*Mg_pore(n-1,j) + 2*t_step*R_net(n-j+1)) / (1+a1);
        
    end
    
end

Mg_pore(:,1)=Mg_pore(:,2);


t_total = t(end);
%-------end of paste--------
t1 = round((t_total/4)/t_step);
t2 = round((t_total/2)/t_step);
t3 = round((t_total/4*3)/t_step);

figure
plot(fliplr(Mg_pore(N,1:J)),z,'linewidth',2)
hold on
plot(fliplr(Mg_pore(N-t1,1:J-t1)),z(1+t1:end),'--','linewidth',2)
plot(fliplr(Mg_pore(N-t2,1:J-t2)),z(1+t2:end),':','linewidth',2)
plot(fliplr(Mg_pore(N-t3,1:J-t3)),z(1+t3:end),'-.','linewidth',2)
 
set(gca,'Ydir','reverse')
title("Site 981");
xlabel('Mg (mM) in pore water');
ylabel('Present-day depth (m)')
set(gca,'FontSize',12)

[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg_data=MagnesiumMgmM(index);

scatter (Mg_data,depth);

legend('t= present day','0.75t','0.5t','0.25t','Mg Data')

print('mg981.jpg','-djpeg','-r600');


R_mg=-R_net;

newName = 'z981';
S.(newName) = z;

newName = 'Rmg981';
S.(newName) = R_mg;

save('mg981.mat', '-struct', 'S'); 


