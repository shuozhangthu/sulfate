% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=1081;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');


site_Number=1082;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=1083;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

site_Number=1084;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');


site_Number=1085;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'*');


site_Number=1086;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'^');
% 
% set(gca,'ColorOrderIndex',1)
% 
% 
% site_Number=1081;
% load fit_ca_1081.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_ca_1081,depth,'-','linewidth',2);
% 
% site_Number=1082;
% load fit_ca_1082.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% plot(fit_ca_1082,depth,'--','linewidth',2);
% 
% site_Number=1083;
% load fit_ca_1083.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_ca_1083,depth,'-.','linewidth',2);
% 
% site_Number=1084;
% load fit_ca_1084.mat;
% index=(Site1==site_Number & CalciumCamM>0);
% depth=Depthmbsf1(index);
% plot(fit_ca_1084,depth,':','linewidth',2);
% 
% 
% site_Number=1085;
% load fit_ca_1085.mat;
% index=(Site1==site_Number & CalciumCamM>0);
% depth=Depthmbsf1(index);
% plot(fit_ca_1085,depth,'-','linewidth',2);
% 
% 
% site_Number=1086;
% load fit_ca_1086.mat;
% index=(Site1==site_Number & CalciumCamM>0);
% depth=Depthmbsf1(index);
% plot(fit_ca_1086,depth,'-.','linewidth',2);

legend('1081','1082','1083','1084','1085','1086','location','best');

print('ca_108x.jpg','-djpeg','-r600');

figure;
hold on
xlabel('[Mg]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=1081;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'o');


site_Number=1082;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'s');

site_Number=1083;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'d');

site_Number=1084;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'h');

site_Number=1085;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'*');

site_Number=1086;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'^');

% set(gca,'ColorOrderIndex',1)
% 
% 
% site_Number=1081;
% load fit_mg_1081.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_mg_1081,depth,'-','linewidth',2);
% 
% site_Number=1082;
% load fit_mg_1082.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% plot(fit_mg_1082,depth,'--','linewidth',2);
% 
% site_Number=1083;
% load fit_mg_1083.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_mg_1083,depth,'-.','linewidth',2);
% 
% site_Number=1084;
% load fit_mg_1084.mat;
% index=(Site1==site_Number & MagnesiumMgmM>0);
% depth=Depthmbsf1(index);
% plot(fit_mg_1084,depth,':','linewidth',2);
% 
% site_Number=1085;
% load fit_mg_1085.mat;
% index=(Site1==site_Number & MagnesiumMgmM>0);
% depth=Depthmbsf1(index);
% plot(fit_mg_1085,depth,'-','linewidth',2);
% 
% site_Number=1086;
% load fit_mg_1086.mat;
% index=(Site1==site_Number & MagnesiumMgmM>0);
% depth=Depthmbsf1(index);
% plot(fit_mg_1086,depth,'--','linewidth',2);
legend('1081','1082','1083','1084','1085','1086','location','best');

print('mg_108x.jpg','-djpeg','-r600');


figure;
hold on
xlabel('[SO_4^{2-}]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=1081;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'o');


site_Number=1082;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'s');

site_Number=1083;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'d');

site_Number=1084;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'h');

site_Number=1085;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'*');

site_Number=1086;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'^');
% 
% set(gca,'ColorOrderIndex',1)
% 
% 
% site_Number=1081;
% load sulfate1081.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_1081,z1081,'-','linewidth',2);
% 
% site_Number=1082;
% load sulfate1082.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% plot(fit_sulfate_1082,z1082,'-.','linewidth',2);
% 
% site_Number=1083;
% load sulfate1083.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_1083,z1083,'-.','linewidth',2);
% 
% site_Number=1084;
% load sulfate1084.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_1084,z1084,':','linewidth',2);
% 
% site_Number=1085;
% load sulfate1085.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_1085,z1085,'-','linewidth',2);
% 
% 
% site_Number=1086;
% load sulfate1086.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_1086,z1086,'--','linewidth',2);


legend('1081','1082','1083','1084','1085','1086','location','best');

print('su_108x.jpg','-djpeg','-r600');

figure;
hold on
xlabel('Alkalinity (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=1081;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'o');


site_Number=1082;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'s');

site_Number=1083;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'d');

site_Number=1084;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'h');

site_Number=1085;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'*');

site_Number=1086;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'^');

% set(gca,'ColorOrderIndex',1)
% 
% 
% site_Number=1081;
% load fit_alk_1081.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% plot(fit_alk_1081,depth,'-','linewidth',2);
% 
% site_Number=1082;
% load fit_alk_1082.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% plot(fit_alk_1082,depth,'-.','linewidth',2);
% 
% site_Number=1083;
% load fit_alk_1083.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% plot(fit_alk_1083,depth,'-.','linewidth',2);
% 
% site_Number=1084;
% load fit_alk_1084.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% plot(fit_alk_1084,depth,':','linewidth',2);
% 
% site_Number=1085;
% load fit_alk_1085.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% plot(fit_alk_1085,depth,'-','linewidth',2);
% 
% site_Number=1086;
% load fit_alk_1086.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0);
% depth=Depthmbsf1(index);
% plot(fit_alk_1086,depth,'--','linewidth',2);

legend('1081','1082','1083','1084','1085','1086','location','best');

print('alk_108x.jpg','-djpeg','-r600');

