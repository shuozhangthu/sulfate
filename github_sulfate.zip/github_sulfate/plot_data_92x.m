% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
set(gcf, 'Position',  [500, 100, 900, 800])

subplot(2,2,2)
title('(b)')
hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;


site_Number=925;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');

site_Number=926;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');


site_Number=927;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

site_Number=928;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

site_Number=929;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'*');

set(gca,'ColorOrderIndex',1)

site_Number=925;
load fit_ca_925.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_925,depth,'-','linewidth',2);

site_Number=926;
load fit_ca_926.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_926,depth,'--','linewidth',2);

site_Number=927;
load fit_ca_927.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_927,depth,'-.','linewidth',2);

site_Number=928;
load fit_ca_928.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_928,depth,':','linewidth',2);

site_Number=929;
load fit_ca_929.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_929,depth,'-','linewidth',2);

% legend('925','926','927','928','929','location','best');

% print('ca_92x.jpg','-djpeg','-r600');

subplot(2,2,3)
title('(c)')
hold on
xlabel('[Mg]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=925;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'o');

site_Number=926;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'s');


site_Number=927;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'d');

site_Number=928;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'h');

site_Number=929;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'*');

set(gca,'ColorOrderIndex',1)

site_Number=925;
load fit_mg_925.mat;
index=(Site1==site_Number & MagnesiumMgmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_mg_925,depth,'-','linewidth',2);

site_Number=926;
load fit_mg_926.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_mg_926,depth,'--','linewidth',2);

site_Number=927;
load fit_mg_927.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_mg_927,depth,'-.','linewidth',2);

site_Number=928;
load fit_mg_928.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_mg_928,depth,':','linewidth',2);

site_Number=929;
load fit_mg_929.mat;
index=(Site1==site_Number & MagnesiumMgmM>0);
depth=Depthmbsf1(index);
plot(fit_mg_929,depth,'-','linewidth',2);

% legend('925','926','927','928','929','location','best');

% print('mg_92x.jpg','-djpeg','-r600');


subplot(2,2,1)
title('(a)');
hold on
xlabel('[SO_4^{2-}]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=925;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'o');

site_Number=926;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'s');

site_Number=927;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'d');

site_Number=928;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'h');

site_Number=929;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'*');

set(gca,'ColorOrderIndex',1)

site_Number=925;
load sulfate925.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_925,z925,'-','linewidth',2);

site_Number=926;
load sulfate926.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_926,z926,'--','linewidth',2);

site_Number=927;
load sulfate927.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sulfate_927,z927,'-.','linewidth',2);

site_Number=928;
load sulfate928.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_928,z928,':','linewidth',2);

site_Number=929;
load sulfate929.mat;
index=(Site1==site_Number & SulfateSO4mM>0);
depth=Depthmbsf1(index);
plot(fit_sulfate_929,z929,'-','linewidth',2);

legend('925','926','927','928','929','location','best');

% print('su_92x.jpg','-djpeg','-r600');

subplot(2,2,4)
title('(d)');
hold on
xlabel('Alkalinity (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=925;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'o');

site_Number=926;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'s');


site_Number=927;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'d');

site_Number=928;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'h');

site_Number=929;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'*');

set(gca,'ColorOrderIndex',1)

site_Number=925;
load fit_alk_925.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_alk_925,depth,'-','linewidth',2);

site_Number=926;
load fit_alk_926.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_926,depth,'--','linewidth',2);

site_Number=927;
load fit_alk_927.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_alk_927,depth,'-.','linewidth',2);

site_Number=928;
load fit_alk_928.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_928,depth,':','linewidth',2);

site_Number=929;
load fit_alk_929.mat;
index=(Site1==site_Number & AlkalinityALKmM>0 & Depthmbsf1<400);
depth=Depthmbsf1(index);
plot(fit_alk_929,depth,'-','linewidth',2);

% legend('925','926','927','928','929','location','best');

% print('alk_92x.jpg','-djpeg','-r600');
print('all_92x.pdf','-dpdf','-r600');


figure;
hold on
xlabel('pH');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=925;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'o');

site_Number=926;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'s');


site_Number=927;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'d');

site_Number=928;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'h');

site_Number=929;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'*');


% legend('925','926','927','928','929','location','best');

% print('pH_92x.jpg','-djpeg','-r600');

