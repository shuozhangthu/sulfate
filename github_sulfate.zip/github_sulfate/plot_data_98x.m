% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
set(gcf, 'Position',  [500, 100, 900, 800])

subplot(2,2,2)
title('(b)')
hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=981;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');


site_Number=983;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=984;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

% site_Number=987;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Ca=CalciumCamM(index);
% scatter(Ca,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=981;
load fit_ca_981.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_981,depth,'-','linewidth',2);

site_Number=983;
load fit_ca_983.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_983,depth,'-.','linewidth',2);

site_Number=984;
load fit_ca_984.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_984,depth,'--','linewidth',2);

% site_Number=987;
% load fit_ca_987.mat;
% index=(Site1==site_Number & CalciumCamM>0);
% depth=Depthmbsf1(index);
% plot(fit_ca_987,depth,':','linewidth',2);

% legend('981','983','984','location','best');

% print('ca_98x.jpg','-djpeg','-r600');

subplot(2,2,3)
title('(c)')
hold on
xlabel('[Mg]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=981;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'o');


site_Number=983;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'s');

site_Number=984;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'d');

% site_Number=987;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Mg=MagnesiumMgmM(index);
% scatter(Mg,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=981;
load fit_mg_981.mat;
index=(Site1==site_Number & MagnesiumMgmM>0);
depth=Depthmbsf1(index);
plot(fit_mg_981,depth,'-','linewidth',2);

site_Number=983;
load fit_mg_983.mat;
index=(Site1==site_Number & MagnesiumMgmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_mg_983,depth,'--','linewidth',2);

site_Number=984;
load fit_mg_984.mat;
index=(Site1==site_Number & MagnesiumMgmM>0);
depth=Depthmbsf1(index);
plot(fit_mg_984,depth,'-.','linewidth',2);

% site_Number=987;
% load fit_mg_987.mat;
% index=(Site1==site_Number & MagnesiumMgmM>0);
% depth=Depthmbsf1(index);
% plot(fit_mg_987,depth,':','linewidth',2);

% legend('981','983','984','location','best');

% print('mg_98x.jpg','-djpeg','-r600');


subplot(2,2,1)
title('(a)');
hold on
xlabel('[SO_4^{2-}]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=981;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'o');


site_Number=983;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'s');

site_Number=984;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'d');

% site_Number=987;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Su=SulfateSO4mM(index);
% scatter(Su,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=981;
load sulfate981.mat;
index=(Site1==site_Number & SulfateSO4mM>0);
depth=Depthmbsf1(index);
plot(fit_sulfate_981,z981,'-','linewidth',2);

site_Number=983;
load sulfate983.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sulfate_983,z983,'--','linewidth',2);

site_Number=984;
load sulfate984.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_984,z984,'-.','linewidth',2);

% site_Number=987;
% load sulfate987.mat;
% index=(Site1==site_Number & SulfateSO4mM>=0);
% depth=Depthmbsf1(index);
% plot(fit_sulfate_987,z987,':','linewidth',2);
% 
legend('981','983','984','location','best');
% 
% print('su_98x.jpg','-djpeg','-r600');

subplot(2,2,4)
title('(d)');
hold on
xlabel('Alkalinity (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=981;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'o');


site_Number=983;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'s');

site_Number=984;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'d');

% site_Number=987;
% index=(Site1==site_Number &Depthmbsf1<352);
% depth=Depthmbsf1(index);
% alk=AlkalinityALKmM(index);
% scatter(alk,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=981;
load fit_alk_981.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_981,depth,'-','linewidth',2);

site_Number=983;
load fit_alk_983.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_alk_983,depth,'--','linewidth',2);

site_Number=984;
load fit_alk_984.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_984,depth,'-.','linewidth',2);

% site_Number=987;
% load fit_alk_987.mat;
% index=(Site1==site_Number & AlkalinityALKmM>0 &Depthmbsf1<352);
% depth=Depthmbsf1(index);
% plot(fit_alk_987,depth,':','linewidth',2);

% legend('981','983','984','location','best');
% 
% print('alk_98x.jpg','-djpeg','-r600');
print('all_98x.pdf','-dpdf','-r600');


figure;
hold on
xlabel('pH');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=981;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'o');


site_Number=983;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'s');

site_Number=984;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
pH=pHpHna(index);
scatter(pH,depth,'d');

legend('981','983','984','location','best');

% print('pH_98x.jpg','-djpeg','-r600');
