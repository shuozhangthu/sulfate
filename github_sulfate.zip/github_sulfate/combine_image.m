close all

img1=imread('su_80x.jpg');
img2=imread('ca_80x.jpg');
img3=imread('mg_80x.jpg');
img4=imread('alk_80x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_fit_80x.jpg','-djpeg','-r300')


img1=imread('su_92x.jpg');
img2=imread('ca_92x.jpg');
img3=imread('mg_92x.jpg');
img4=imread('alk_92x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_fit_92x.jpg','-djpeg','-r300')

img1=imread('su_98x.jpg');
img2=imread('ca_98x.jpg');
img3=imread('mg_98x.jpg');
img4=imread('alk_98x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_fit_98x.jpg','-djpeg','-r300')

img1=imread('su_108x.jpg');
img2=imread('ca_108x.jpg');
img3=imread('mg_108x.jpg');
img4=imread('alk_108x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_fit_108x.jpg','-djpeg','-r300')


img1=imread('Rsu_80x.jpg');
img2=imread('Rca_80x.jpg');
img3=imread('Rmg_80x.jpg');
img4=imread('Ralk_80x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_R_80x.jpg','-djpeg','-r300')


img1=imread('Rsu_92x.jpg');
img2=imread('Rca_92x.jpg');
img3=imread('Rmg_92x.jpg');
img4=imread('Ralk_92x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_R_92x.jpg','-djpeg','-r300')

img1=imread('Rsu_98x.jpg');
img2=imread('Rca_98x.jpg');
img3=imread('Rmg_98x.jpg');
img4=imread('Ralk_98x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_R_98x.jpg','-djpeg','-r300')

img1=imread('Rsu_108x.jpg');
img2=imread('Rca_108x.jpg');
img3=imread('Rmg_108x.jpg');
img4=imread('Ralk_108x.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('all_R_108x.jpg','-djpeg','-r300')

img1=imread('sulfate_sedimentation.jpg');
img2=imread('sulfate_water.jpg');
img3=imread('sulfate_carbonate.jpg');
img4=imread('sulfate_organic.jpg');

img=[img1 img2; img3 img4];
imshow(img);
print('sulfate_control.jpg','-djpeg','-r300')


