% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_ca_803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_803,depth,'-','linewidth',2);

site_Number=805;
load fit_ca_805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_805,depth,'--','linewidth',2);

site_Number=806;
load fit_ca_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_806,depth,'-.','linewidth',2);

site_Number=807;
load fit_ca_807.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_807,depth,':','linewidth',2);

legend('803','805','806','807','location','best');

print('ca_80x.jpg','-djpeg','-r600');

figure;
hold on
xlabel('[Mg]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'d');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Mg=MagnesiumMgmM(index);
scatter(Mg,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_mg_803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_mg_803,depth,'-','linewidth',2);

site_Number=805;
load fit_mg_805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_mg_805,depth,'--','linewidth',2);

site_Number=806;
load fit_mg_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_mg_806,depth,'-.','linewidth',2);

site_Number=807;
load fit_mg_807.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_mg_807,depth,':','linewidth',2);

legend('803','805','806','807','location','best');

print('mg_80x.jpg','-djpeg','-r600');


figure;
hold on
xlabel('[SO_4^{2-}]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'d');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Su=SulfateSO4mM(index);
scatter(Su,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=803;
load sulfate803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_803,z803,'-','linewidth',2);

site_Number=805;
load sulfate805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sulfate_805,z805,'--','linewidth',2);

site_Number=806;
load sulfate806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sulfate_806,z806,'-.','linewidth',2);

site_Number=807;
load sulfate807.mat;
index=(Site1==site_Number & SulfateSO4mM>0);
depth=Depthmbsf1(index);
plot(fit_sulfate_807,z807,':','linewidth',2);

legend('803','805','806','807','location','best');

print('su_80x.jpg','-djpeg','-r600');

figure;
hold on
xlabel('Alkalinity (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'d');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
alk=AlkalinityALKmM(index);
scatter(alk,depth,'h');

set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_alk_803.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_803,depth,'-','linewidth',2);

site_Number=805;
load fit_alk_805.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_alk_805,depth,'--','linewidth',2);

site_Number=806;
load fit_alk_806.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_806,depth,'-.','linewidth',2);

site_Number=807;
load fit_alk_807.mat;
index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
plot(fit_alk_807,depth,':','linewidth',2);

legend('803','805','806','807','location','best');

print('alk_80x.jpg','-djpeg','-r600');

