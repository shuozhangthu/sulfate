clear all
close all
load sulfate803.mat;
load ca803.mat;
load mg803.mat;
load alk803.mat;
load sulfate805.mat;
load ca805.mat;
load mg805.mat;
load alk805.mat;
load sulfate806.mat;
load ca806.mat;
load mg806.mat;
load alk806.mat;
load sulfate807.mat;
load ca807.mat;
load mg807.mat;
load alk807.mat;
load sulfate925.mat;
load ca925.mat;
load mg925.mat;
load alk925.mat;
load sulfate926.mat;
load ca926.mat;
load mg926.mat;
load alk926.mat;
load sulfate927.mat;
load ca927.mat;
load mg927.mat;
load alk927.mat;
load sulfate928.mat;
load ca928.mat;
load mg928.mat;
load alk928.mat;
load sulfate929.mat;
load ca929.mat;
load mg929.mat;
load alk929.mat;
load sulfate981.mat;
load ca981.mat;
load mg981.mat;
load alk981.mat;
load sulfate983.mat;
load ca983.mat;
load mg983.mat;
load alk983.mat;
load sulfate984.mat;
load ca984.mat;
load mg984.mat;
load alk984.mat;
load sulfate987.mat;
load ca987.mat;
load mg987.mat;
load alk987.mat;
load sulfate1081.mat;
load ca1081.mat;
load mg1081.mat;
load alk1081.mat;
load sulfate1082.mat;
load ca1082.mat;
load mg1082.mat;
load alk1082.mat;
load sulfate1083.mat;
load ca1083.mat;
load mg1083.mat;
load alk1083.mat;
load sulfate1084.mat;
load ca1084.mat;
load mg1084.mat;
load alk1084.mat;
load sulfate1085.mat;
load ca1085.mat;
load mg1085.mat;
load alk1085.mat;
load sulfate1086.mat;
load ca1086.mat;
load mg1086.mat;
load alk1086.mat;

set(0, 'DefaultLineLineWidth', 2);


Rsu=[Rsu803(1),Rsu805(1),Rsu806(1),Rsu807(1),Rsu925(1),Rsu926(1),Rsu927(1),Rsu928(1),Rsu929(1),Rsu981(1),Rsu983(1),Rsu984(1),Rsu987(1),Rsu1081(1),Rsu1082(1),Rsu1083(1),Rsu1084(1),Rsu1085(1),Rsu1086(1)];
Rca=[Rca803(1),Rca805(1),Rca806(1),Rca807(1),Rca925(1),Rca926(1),Rca927(1),Rca928(1),Rca929(1),Rca981(1),Rca983(1),Rca984(1),Rca987(1),Rca1081(1),Rca1082(1),Rca1083(1),Rca1084(1),Rca1085(1),Rca1086(1)];
Rmg=[Rmg803(1),Rmg805(1),Rmg806(1),Rmg807(1),Rmg925(1),Rmg926(1),Rmg927(1),Rmg928(1),Rmg929(1),Rmg981(1),Rmg983(1),Rmg984(1),Rmg987(1),Rmg1081(1),Rmg1082(1),Rmg1083(1),Rmg1084(1),Rmg1085(1),Rmg1086(1)];
Ralk=[Ralk803(1),Ralk805(1),Ralk806(1),Ralk807(1),Ralk925(1),Ralk926(1),Ralk927(1),Ralk928(1),Ralk929(1),Ralk981(1),Ralk983(1),Ralk984(1),Ralk987(1),Ralk1081(1),Ralk1082(1),Ralk1083(1),Ralk1084(1),Ralk1085(1),Ralk1086(1)];

figure;
hold on
scatter(Rsu,Rca+200,'o');
scatter(Rsu,Rmg+100,'s');
scatter(Rsu,Ralk,'h');
xlim([1,200]);

x=[1:10:1000];
y0=0+x*0;
y1=100+x*0;
y2=200+x*0;
plot(x,y0,'k--','linewidth',1);
plot(x,y1,'k--','linewidth',1);
plot(x,y2,'k--','linewidth',1);
legend('Ca loss + 200','Mg loss + 100','Alkalinity gain','location','best');
xlabel('Rate of sulfate loss in pore fluid (mM/Myr)');
ylabel('Rate of concentration change in pore fluid (mM/Myr)');
set(gca,'FontSize',10,'FontWeight','bold');
set(gca,'xscale','log');
box on
ax = gca;
ax.LineWidth = 1;
print('sulfate_ca_mg_alk.jpg','-djpeg','-r300');


Rsu80x=[Rsu803(1),Rsu805(1),Rsu806(1),Rsu807(1)];
Rsu92x=[Rsu925(1),Rsu926(1),Rsu927(1),Rsu928(1),Rsu929(1)];
Rsu98x=[Rsu981(1),Rsu983(1),Rsu984(1),Rsu987(1)];
Rsu108x=[Rsu1081(1),Rsu1082(1),Rsu1083(1),Rsu1084(1),Rsu1085(1),Rsu1086(1)];
Rca80x=[Rca803(1),Rca805(1),Rca806(1),Rca807(1)];
Rca92x=[Rca925(1),Rca926(1),Rca927(1),Rca928(1),Rca929(1)];
Rca98x=[Rca981(1),Rca983(1),Rca984(1),Rca987(1)];
Rca108x=[Rca1081(1),Rca1082(1),Rca1083(1),Rca1084(1),Rca1085(1),Rca1086(1)];
Rmg80x=[Rmg803(1),Rmg805(1),Rmg806(1),Rmg807(1)];
Rmg92x=[Rmg925(1),Rmg926(1),Rmg927(1),Rmg928(1),Rmg929(1)];
Rmg98x=[Rmg981(1),Rmg983(1),Rmg984(1),Rmg987(1)];
Rmg108x=[Rmg1081(1),Rmg1082(1),Rmg1083(1),Rmg1084(1),Rmg1085(1),Rmg1086(1)];
Ralk80x=[Ralk803(1),Ralk805(1),Ralk806(1),Ralk807(1)];
Ralk92x=[Ralk925(1),Ralk926(1),Ralk927(1),Ralk928(1),Ralk929(1)];
Ralk98x=[Ralk981(1),Ralk983(1),Ralk984(1),Ralk987(1)];
Ralk108x=[Ralk1081(1),Ralk1082(1),Ralk1083(1),Ralk1084(1),Ralk1085(1),Ralk1086(1)];

figure;
hold on
scatter(Rsu80x,Rca80x+Rmg80x+0.5*Ralk80x,'o');
scatter(Rsu92x,Rca92x+Rmg92x+0.5*Ralk92x,'s');
scatter(Rsu98x,Rca98x+Rmg98x+0.5*Ralk98x,'h');
scatter(Rsu108x,Rca108x+Rmg108x+0.5*Ralk108x,'d');
xlabel('Rate of sulfate loss in pore fluid (mM/Myr)');
ylabel('Ca loss + Mg loss + 0.5*alkalinity gain \newlinerate in pore fluid (mM/Myr)');
set(gca,'FontSize',10,'FontWeight','bold','xscale','log','yscale','log')
box on
ax = gca;
ax.LineWidth = 1;

x1=[1:1:1000];
y1=x1;
x2=[1:1:1000];
y2=2*x2;

plot(x1,y1,'k--','linewidth',1);
% plot(x2,y2,'k-.','linewidth',1);

legend('803-807','925-929','981-987','1081-1086','y=x','location','southeast');

print('sulfate_total.jpg','-djpeg','-r300');


car80x=[89.3,91.5,92.5,92.4];
car92x=[66.40,61.90,58.00,57.50,49.60];
car98x=[60.48,16.59,8.01,4.29];
car108x=[17.77,42.95,60.37,39.3,69.2,82.79];

org80x=[0.093,0,0.148,0.192];
org92x=[0.124,0.138,0.081,0.165,0.099];
org98x=[0.315,0.280,0.209,0.542];
org108x=[4.050,5.670,1.040,5.840,0.770,1.330];

sed80x=[16.90,26.00,36.90,30.40];
sed92x=[26.00,22.60,25.90,18.90,16.82];
sed98x=[150.00,135.14,119.05,151.52];
sed108x=[66.67,108.70,161.29,357.14,54.35,25.00];

water80x=[3409.7,3188.5,2520.7,2803.8];
water92x=[3042.2,3598.4,3313.7,4010.7,4357.6];
water98x=[2173.1,1983,1649.3,1671.6];
water108x=[794.1,1279.3,2178.1,1991.9,1713.2,781.1];

Rsu80x=[Rsu803(1),Rsu805(1),Rsu806(1),Rsu807(1)];
Rsu92x=[Rsu925(1),Rsu926(1),Rsu927(1),Rsu928(1),Rsu929(1)];
Rsu98x=[Rsu981(1),Rsu983(1),Rsu984(1),Rsu987(1)];
Rsu108x=[Rsu1081(1),Rsu1082(1),Rsu1083(1),Rsu1084(1),Rsu1085(1),Rsu1086(1)];

figure
hold on
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

scatter(car80x,Rsu80x,'o','linewidth',1.5);
scatter(car92x,Rsu92x,'s','linewidth',1.5);
scatter(car98x,Rsu98x,'d','linewidth',1.5);
scatter(car108x,Rsu108x,'h','linewidth',1.5);
set(gca,'yscale','log');

xlabel('Carbonate content (%)');
ylabel('Rate of sulfate loss in pore fluid (mM/Myr)');
legend('Site 803-807','925-929','981-987','1081-1086','location','best');
print('sulfate_carbonate.jpg','-djpeg','-r300');

figure
hold on
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

scatter(org80x,Rsu80x,'o','linewidth',1.5);
scatter(org92x,Rsu92x,'s','linewidth',1.5);
scatter(org98x,Rsu98x,'d','linewidth',1.5);
scatter(org108x,Rsu108x,'h','linewidth',1.5);

set(gca,'yscale','log');
xlabel('Organic carbon (%)');
ylabel('Rate of sulfate loss in pore fluid (mM/Myr)');
legend('Site 803-807','925-929','981-987','1081-1086','location','best');
print('sulfate_organic.jpg','-djpeg','-r300');

figure
hold on
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

scatter(sed80x,Rsu80x,'o','linewidth',1.5);
scatter(sed92x,Rsu92x,'s','linewidth',1.5);
scatter(sed98x,Rsu98x,'d','linewidth',1.5);
scatter(sed108x,Rsu108x,'h','linewidth',1.5);

set(gca,'yscale','log');
xlabel('Sedimentation rate (m/Myr)');
ylabel('Rate of sulfate loss in pore fluid (mM/Myr)');
legend('Site 803-807','925-929','981-987','1081-1086','location','best');
print('sulfate_sedimentation.jpg','-djpeg','-r300');


figure
hold on
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

scatter(water80x,Rsu80x,'o','linewidth',1.5);
scatter(water92x,Rsu92x,'s','linewidth',1.5);
scatter(water98x,Rsu98x,'d','linewidth',1.5);
scatter(water108x,Rsu108x,'h','linewidth',1.5);

set(gca,'yscale','log');
xlabel('Water depth (m)');
ylabel('Rate of sulfate loss in pore fluid (mM/Myr)');
legend('Site 803-807','925-929','981-987','1081-1086','location','best');
print('sulfate_water.jpg','-djpeg','-r300');



figure;
hold on
scatter(water80x,Rsu80x./(Rca80x+Rmg80x+0.5*Ralk80x),'o');
scatter(water92x,Rsu92x./(Rca92x+Rmg92x+0.5*Ralk92x),'s');
scatter(water98x,Rsu98x./(Rca98x+Rmg98x+0.5*Ralk98x),'h');
scatter(water108x,Rsu108x./(Rca108x+Rmg108x+0.5*Ralk108x),'d');
xlabel('Water depth (m)');
ylabel('Sulfate loss/(Ca loss + Mg loss + 0.5*alkalinity gain)');
set(gca,'FontSize',10,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

legend('803-807','925-929','981-987','1081-1086','y=x','location','northwest');

print('test.jpg','-djpeg','-r300');