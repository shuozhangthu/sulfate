
site_Number = 984;

%-------input data----------
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
Ca_data=CalciumCamM(index);


[depth, a_order] = sort(depth);
Ca_data = Ca_data(a_order,:);

alpha0=0.00015;
beta0=600;
gamma0=600;
v0=0;
grc_ca0=0;

c0=[alpha0,beta0,gamma0,v0,grc_ca0];
lb=[0,-100,-100000,0,-100];
ub=[0,100,100000,0,100];

c = lsqcurvefit(@s984_Ca_function,c0,depth,Ca_data,lb,ub)



figure
plot(s984_Ca_function(c,depth),depth,'linewidth',2)
set(gca,'Ydir','reverse')
title('Calcium (mM) in pore water (site:984)')
xlabel('Calcium (mM) in pore water');
ylabel('Depth (m)')
set(gca,'FontSize',12)

hold on;

scatter (Ca_data,depth);

newName = 'c984';
S.(newName) = [site_Number,c];
save('parameters_Ca_984.mat', '-struct', 'S'); 


newName = 'fit_ca_984';
S.(newName) = s984_Ca_function(c,depth);
save('fit_ca_984.mat', '-struct', 'S'); 