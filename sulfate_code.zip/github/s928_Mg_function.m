function C=s928_Mg_function(m,mdata)

alpha=m(1);
beta=m(2);
gamma=m(3);
v=m(4);
gra_mg = m(5);

load workspace_928.mat;
%------- initialize the paramter------

R_net=alpha+beta*exp(-z/gamma);

D0 = zeros(length(z),1);
D_mg = zeros(length(z),1);

for i = 1:length(z)
    D0(i) = (3.69+ 0.169 * (temp_T(i)-273.15)) * 3.65 * 24 * 36;
    D_mg(i) = D0(i) / (1-log(phi_z(i)^2))*0.9265;
end


%------- initialize the paramter------
J = length(z);
N = length(t);
Mg_pore = zeros(N,J);
K_aq = 0;   % adsoprtion coefficient

for n =1:N
    Mg_pore(n,n:n+1) = 52.58 + 0*t(N-n+1);
end

Mg_pore(2,1) = Mg_pore(2,2)+ z_step(2)* gra_mg;


%-----calculation
for n = 2: N-1
    
    a10 = 2*D_mg(n-2+1)*t_step/z_step(n-2+2)^2;
    b10 = t_step*v/z_step(n-2+2);
    
    Mg_pore(n+1,2) = ((a10-b10)*Mg_pore(n,2+1) + (a10+b10)*(Mg_pore(n, 3) + 2 * z_step(n)* gra_mg) + (1-a10)*Mg_pore(n-1,2) + 2*t_step*R_net(n-2+1)) / (1+a10);
    
    for j = 3:n
        
        a1 = 2*D_mg(n-j+1)*t_step/z_step(n-j+2)^2;
        b1 = t_step*v/z_step(n-j+2);
        
        Mg_pore(n+1,j) = ((a1-b1)*Mg_pore(n,j+1) + (a1+b1)*Mg_pore(n,j-1) + (1-a1)*Mg_pore(n-1,j) + 2*t_step*R_net(n-j+1)) / (1+a1);
        
    end
    
end

Mg_pore(:,1)=Mg_pore(:,2);


C=interp1(z(1:N),fliplr(Mg_pore(N,1:J)),mdata);
