clc
clear all
site_Number = 1086;

[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');
index3=(Site1==site_Number);
depth3=Depthmbsf1(index3);
sulfate_data=SulfateSO4mM(index3);

[depth3, a_order] = sort(depth3);
sulfate_data = sulfate_data(a_order,:);

G00 = 85;  %[mM/1 porewater]  by fitting
k_su0=5;
v0=0;
Ks0=10.0;
gra_su0=-0.00;

x0=[G00,k_su0,v0,Ks0,gra_su0];

lb=[0 ,0 ,v0 ,0,0];
ub=[20000,100,v0,1000,0];

x = lsqcurvefit(@sulfate_1086_function,x0,depth3,sulfate_data,lb,ub)

figure;
plot(sulfate_1086_function(x,depth3),depth3,'linewidth',2)
hold on
scatter(sulfate_data,depth3,'ko')
hold on
set(gca,'Ydir','reverse')
title("Sulfate concentration in pore water (site:1086)")
xlabel('Sulfate (mM) in pore water');
ylabel('Depth (m)')
set(gca,'FontSize',12)


newName = 'x1086';
S.(newName) = [site_Number,x];
save('parameters_sulfate_1086.mat', '-struct', 'S'); 



newName = 'fit_su_1086';
S.(newName) = sulfate_1086_function(x,depth3);
save('fit_sulfate_1086.mat', '-struct', 'S'); 
% print -djpeg 1086_Sulfate.jpg -r600