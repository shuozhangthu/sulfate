
site_Number = 928;

%-------input data----------
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

index=(Site1==site_Number & AlkalinityALKmM>0);
depth=Depthmbsf1(index);
alk_data=AlkalinityALKmM(index);


[depth, a_order] = sort(depth);
alk_data = alk_data(a_order,:);

alpha0=0.00015;
beta0=600;
gamma0=600;
v0=0;
grc_alk=0;

a0=[alpha0,beta0,gamma0,v0,grc_alk];
lb=[-100,-100,-100000,0,-100];
ub=[100,100,100000,0,100];

a = lsqcurvefit(@s928_alk_function,a0,depth,alk_data,lb,ub)



figure
plot(s928_alk_function(a,depth),depth,'linewidth',2)
set(gca,'Ydir','reverse')
title('Alkalinity (mM) in pore water (site:928)')
xlabel('Alkalinity (mM) in pore water');
ylabel('Depth (m)')
set(gca,'FontSize',12)

hold on;

scatter (alk_data,depth);


newName = 'a928';
S.(newName) = [site_Number,a];
save('parameters_alk_928.mat', '-struct', 'S'); 


newName = 'fit_alk_928';
S.(newName) = s928_alk_function(a,depth);
save('fit_alk_928.mat', '-struct', 'S'); 