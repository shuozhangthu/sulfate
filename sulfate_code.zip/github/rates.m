clear all
close all
load sulfate803.mat;
load ca803.mat;
load mg803.mat;
load alk803.mat;
load sulfate805.mat;
load ca805.mat;
load mg805.mat;
load alk805.mat;
load sulfate806.mat;
load ca806.mat;
load mg806.mat;
load alk806.mat;
load sulfate807.mat;
load ca807.mat;
load mg807.mat;
load alk807.mat;
load sulfate925.mat;
load ca925.mat;
load mg925.mat;
load alk925.mat;
load sulfate926.mat;
load ca926.mat;
load mg926.mat;
load alk926.mat;
load sulfate927.mat;
load ca927.mat;
load mg927.mat;
load alk927.mat;
load sulfate928.mat;
load ca928.mat;
load mg928.mat;
load alk928.mat;
load sulfate929.mat;
load ca929.mat;
load mg929.mat;
load alk929.mat;
load sulfate981.mat;
load ca981.mat;
load mg981.mat;
load alk981.mat;
load sulfate983.mat;
load ca983.mat;
load mg983.mat;
load alk983.mat;
load sulfate984.mat;
load ca984.mat;
load mg984.mat;
load alk984.mat;
load sulfate987.mat;
load ca987.mat;
load mg987.mat;
load alk987.mat;
load sulfate1081.mat;
load ca1081.mat;
load mg1081.mat;
load alk1081.mat;
load sulfate1082.mat;
load ca1082.mat;
load mg1082.mat;
load alk1082.mat;
load sulfate1083.mat;
load ca1083.mat;
load mg1083.mat;
load alk1083.mat;
load sulfate1084.mat;
load ca1084.mat;
load mg1084.mat;
load alk1084.mat;
load sulfate1085.mat;
load ca1085.mat;
load mg1085.mat;
load alk1085.mat;
load sulfate1086.mat;
load ca1086.mat;
load mg1086.mat;
load alk1086.mat;

set(0, 'DefaultLineLineWidth', 2);

figure;
hold on
plot(Rsu803,z803,'-');
plot(Rsu805,z805,'--');
plot(Rsu806,z806,'-.');
plot(Rsu807,z807,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{sulfate} (mM/Myr)');
ylabel('Depth (m)')
legend('803','805','806','807');
print('Rsu_80x.jpg','-djpeg','-r300');

figure;
hold on
plot(Rca803,z803,'-');
plot(Rca805,z805,'--');
plot(Rca806,z806,'-.');
plot(Rca807,z807,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;



set(gca,'Ydir','reverse')
xlabel('R_{Ca} (mM/Myr)');
ylabel('Depth (m)')
legend('803','805','806','807','location','best');
print('Rca_80x.jpg','-djpeg','-r300');


figure;
hold on
plot(Ralk803,z803,'-');
plot(Ralk805,z805,'--');
plot(Ralk806,z806,'-.');
plot(Ralk807,z807,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{alkalinity} (mM/Myr)');
ylabel('Depth (m)')
legend('803','805','806','807');
print('Ralk_80x.jpg','-djpeg','-r300');



figure;
hold on
plot(Rmg803,z803,'-');
plot(Rmg805,z805,'--');
plot(Rmg806,z806,'-.');
plot(Rmg807,z807,':');

set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{Mg} (mM/Myr)');
ylabel('Depth (m)')
legend('803','805','806','807');
print('Rmg_80x.jpg','-djpeg','-r300');



figure;
hold on
plot(Rsu925,z925,'-');
plot(Rsu926,z926,'--');
plot(Rsu927,z927,'-.');
plot(Rsu928,z928,':');
plot(Rsu929,z929,'-');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{sulfate} (mM/Myr)');
ylabel('Depth (m)')
legend('925','926','927','928','929');
print('Rsu_92x.jpg','-djpeg','-r300');

figure;
hold on
plot(Rca925,z925,'-');
plot(Rca926,z926,'--');
plot(Rca927,z927,'-.');
plot(Rca928,z928,':');
plot(Rca929,z929,'-');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;



set(gca,'Ydir','reverse')
xlabel('R_{Ca} (mM/Myr)');
ylabel('Depth (m)')
legend('925','926','927','928','929','location','best');
print('Rca_92x.jpg','-djpeg','-r300');


figure;
hold on
plot(Ralk925,z925,'-');
plot(Ralk926,z926,'--');
plot(Ralk927,z927,'-.');
plot(Ralk928,z928,':');
plot(Ralk929,z929,'-');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{alkalinity} (mM/Myr)');
ylabel('Depth (m)')
legend('925','926','927','928','929');
print('Ralk_92x.jpg','-djpeg','-r300');



figure;
hold on
plot(Rmg925,z925,'-');
plot(Rmg926,z926,'--');
plot(Rmg927,z927,'-.');
plot(Rmg928,z928,':');
plot(Rmg929,z929,'-');

set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{Mg} (mM/Myr)');
ylabel('Depth (m)')
legend('925','926','927','928','929');
print('Rmg_92x.jpg','-djpeg','-r300');


figure;
hold on
plot(Rsu981,z981,'-');
plot(Rsu983,z983,'--');
plot(Rsu984,z984,'-.');
plot(Rsu987,z987,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{sulfate} (mM/Myr)');
ylabel('Depth (m)')
legend('981','983','984','987','location','best');
print('Rsu_98x.jpg','-djpeg','-r300');

figure;
hold on
plot(Rca981,z981,'-');
plot(Rca983,z983,'--');
plot(Rca984,z984,'-.');
plot(Rca987,z987,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;



set(gca,'Ydir','reverse')
xlabel('R_{Ca} (mM/Myr)');
ylabel('Depth (m)')
legend('981','983','984','987');
print('Rca_98x.jpg','-djpeg','-r300');


figure;
hold on
plot(Ralk981,z981,'-');
plot(Ralk983,z983,'--');
plot(Ralk984,z984,'-.');
plot(Ralk987,z987,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{alkalinity} (mM/Myr)');
ylabel('Depth (m)')
legend('981','983','984','987');
print('Ralk_98x.jpg','-djpeg','-r300');



figure;
hold on
plot(Rmg981,z981,'-');
plot(Rmg983,z983,'--');
plot(Rmg984,z984,'-.');
plot(Rmg987,z987,':');

set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{Mg} (mM/Myr)');
ylabel('Depth (m)')
legend('981','983','984','987');
print('Rmg_98x.jpg','-djpeg','-r300');


figure;
hold on
plot(Rsu1081,z1081,'-');
plot(Rsu1082,z1082,'--');
plot(Rsu1083,z1083,'-.');
plot(Rsu1084,z1084,':');
plot(Rsu1085,z1085,':');
plot(Rsu1086,z1086,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{sulfate} (mM/Myr)');
ylabel('Depth (m)')
legend('1081','1082','1083','1084','1085','1086');
print('Rsu_108x.jpg','-djpeg','-r300');

figure;
hold on
plot(Rca1081,z1081,'-');
plot(Rca1082,z1082,'--');
plot(Rca1083,z1083,'-.');
plot(Rca1084,z1084,':');
plot(Rca1085,z1085,':');
plot(Rca1086,z1086,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;



set(gca,'Ydir','reverse')
xlabel('R_{Ca} (mM/Myr)');
ylabel('Depth (m)')
legend('1081','1082','1083','1084','1085','1086');
print('Rca_108x.jpg','-djpeg','-r300');


figure;
hold on
plot(Ralk1081,z1081,'-');
plot(Ralk1082,z1082,'--');
plot(Ralk1083,z1083,'-.');
plot(Ralk1084,z1084,':');
plot(Ralk1085,z1085,':');
plot(Ralk1086,z1086,':');
set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{alkalinity} (mM/Myr)');
ylabel('Depth (m)')
legend('1081','1082','1083','1084','1085','1086','location','best'  );
print('Ralk_108x.jpg','-djpeg','-r300');



figure;
hold on
plot(Rmg1081,z1081,'-');
plot(Rmg1082,z1082,'--');
plot(Rmg1083,z1083,'-.');
plot(Rmg1084,z1084,':');
plot(Rmg1085,z1085,':');
plot(Rmg1086,z1086,':');

set(gca,'FontSize',16,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1;

set(gca,'Ydir','reverse')
xlabel('R_{Mg} (mM/Myr)');
ylabel('Depth (m)')
legend('1081','1082','1083','1084','1085','1086','location','best');
print('Rmg_108x.jpg','-djpeg','-r300');