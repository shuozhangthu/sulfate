function C=s1083_alk_function(a,adata)

alpha=a(1);
beta=a(2);
gamma=a(3);
v=a(4);
gra_alk = a(5);

load workspace_1083.mat;

%------- initialize the paramter------
R_net=alpha+beta*exp(-z/gamma);

D0 = zeros(length(z),1);
D_alk = zeros(length(z),1);

for i = 1:length(z)
    D0(i) = (3.69+ 0.169 * (temp_T(i)-273.15)) * 3.65 * 24 * 36;
    D_alk(i) = D0(i) / (1-log(phi_z(i)^2))*1.4265;
end


%------- initialize the paramter------
J = length(z);
N = length(t);
alk_pore = zeros(N,J);
K_aq = 0;   % adsoprtion coefficient


for n =1:N
    alk_pore(n,n:n+1) = 3.23 + 0.0*t(N-n+1);
end

alk_pore(2,1) = alk_pore(2,2)+ z_step(2)* gra_alk;


%-----calculation
for n = 2: N-1
    
    a10 = 2*D_alk(n-2+1)*t_step/z_step(n-2+2)^2;
    b10 = t_step*v/z_step(n-2+2);
    
    alk_pore(n+1,2) = ((a10-b10)*alk_pore(n,2+1) + (a10+b10)*(alk_pore(n, 3) + 2 * z_step(n)* gra_alk) + (1-a10)*alk_pore(n-1,2) + 2*t_step*R_net(n-2+1)) / (1+a10);
    
    for j = 3:n
        
        a1 = 2*D_alk(n-j+1)*t_step/z_step(n-j+2)^2;
        b1 = t_step*v/z_step(n-j+2);
        
        alk_pore(n+1,j) = ((a1-b1)*alk_pore(n,j+1) + (a1+b1)*alk_pore(n,j-1) + (1-a1)*alk_pore(n-1,j) + 2*t_step*R_net(n-j+1)) / (1+a1);
        
    end
    
    
end

alk_pore(:,1)=alk_pore(:,2);


C=interp1(z(1:N),fliplr(alk_pore(N,1:J)),adata);
